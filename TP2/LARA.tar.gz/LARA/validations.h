#ifndef VALIDATIONS_H_INCLUDED
#define VALIDATIONS_H_INCLUDED
#include "user.h"

void validate_string(User reg);


#endif // VALIDATIONS_H_INCLUDED
