#ifndef MAINMENU_H_INCLUDED
#define MAINMENU_H_INCLUDED

void mainMenu();
void menuUsers();

#endif // MAINMENU_H_INCLUDED
