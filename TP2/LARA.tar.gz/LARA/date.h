#ifndef DATE_H_INCLUDED
#define DATE_H_INCLUDED\

struct date{
  int day, month, year;
};

date call_date(date, int &flag );
void show_date(date);
int time_set(date)

#endif // DATE_H_INCLUDED
