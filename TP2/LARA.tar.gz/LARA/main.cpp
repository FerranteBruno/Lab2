#include "mainMenu.h"

int main(){
    mainMenu();

    return 0;
}

