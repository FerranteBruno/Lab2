#include <iostream>
#include <cstring>
#include "validations.h"
#include "user.h"
using namespace std;

void validate_string(User reg){

    if(reg.name==""){
    cout<<"Ingrese nuevamente:"<<endl;
    }

}
